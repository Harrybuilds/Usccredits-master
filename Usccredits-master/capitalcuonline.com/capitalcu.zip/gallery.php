<?php 
$products ="active";
include('header.php'); ?> 
	<!-- gallery -->
	<div class="w3ls-section gallery">
		<div class="container">   
			<div class="w3ls-title">
				<h2 class="h3-w3l">Our Product</h2> 
			</div> 
			<div class="gallery-grids-top">
				<div class="gallery-grids agileits-w3layouts">
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img"> 
						<a class="example-image-link w3-agilepic" href="images/g1.jpg" data-lightbox="example-set" data-title="">
							<img class="example-image img-responsive" src="images/g1.jpg" alt=""/> 
							<div class="w3ls-overlay">
								<h4>We Accept Crypto Currency</h4>
							</div> 
						</a> 
					</div>  
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img hover ehover14">
						<a class="example-image-link w3-agilepic" href="images/g2.jpg" data-lightbox="example-set" data-title="">
							<img class="example-image img-responsive" src="images/g2.jpg" alt=""/> 
							<div class="w3ls-overlay">
								<h4>Accounts can run on zero balance</h4>
							</div> 
						</a> 
					</div>
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img hover ehover14">
						<a class="example-image-link w3-agilepic" href="images/g3.jpg" data-lightbox="example-set" data-title="">
							<img class="example-image img-responsive" src="images/g3.jpg" alt=""/> 
							<div class="w3ls-overlay">
								<h4>Our cards can be used anywhere</h4>
							</div> 
						</a> 
					</div>
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img gallery-mdl hover ehover14"> 
						<a class="example-image-link w3-agilepic" href="images/g3.jpg" data-lightbox="example-set" data-title="">
							<img class="example-image img-responsive" src="images/g3.jpg" alt=""/> 
							<div class="w3ls-overlay">
								<h4>You can fund your cards from anywhere</h4>
							</div> 
						</a>
					</div>  
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img gallery-mdl hover ehover14">
						<a class="example-image-link w3-agilepic" href="images/g4.jpg" data-lightbox="example-set" data-title="">
							<img class="example-image img-responsive" src="images/g4.jpg" alt=""/>
							<div class="w3ls-overlay">
								<h4>Easy Access</h4>
							</div> 
						</a> 
					</div>
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img hover ehover14"> 
						<a class="example-image-link w3-agilepic" href="images/g5.jpg" data-lightbox="example-set" data-title="">
						<img class="example-image img-responsive" src="images/g5.jpg" alt=""/>
							<div class="w3ls-overlay">
								<h4>All currency</h4>
							</div> 
						</a> 
					</div>  
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img hover ehover14">
						<a class="example-image-link w3-agilepic" href="images/g6.jpg" data-lightbox="example-set" data-title="">
							<img class="example-image img-responsive" src="images/g6.jpg" alt=""/> 
							<div class="w3ls-overlay">
								<h4>No limit to your balance</h4>
							</div> 
						</a> 
					</div>
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img hover ehover14">
						<a class="example-image-link w3-agilepic" href="images/g2.jpg" data-lightbox="example-set" data-title="">
							<img class="example-image img-responsive" src="images/g2.jpg" alt=""/>
							<div class="w3ls-overlay">
								<h4>Low balance is not a problem</h4>
							</div> 
						</a>
					</div>	
					<div class="col-md-4 col-sm-4 col-xs-6 gallery-grid-img gallery-mdl hover ehover14">
						<a class="example-image-link w3-agilepic" href="images/g1.jpg" data-lightbox="example-set" data-title="">
							<img class="example-image img-responsive" src="images/g1.jpg" alt=""/>
							<div class="w3ls-overlay">
								<h4>Start accepting crypto. to your accounts.</h4>
							</div> 
						</a> 
					</div>
					<div class="clearfix"> </div>	
					<script src="js/lightbox-plus-jquery.min.js"></script>	
				</div> 
			</div> 
		</div>
	</div>
	<!-- //gallery -->     

<?php include('footer.php'); ?>